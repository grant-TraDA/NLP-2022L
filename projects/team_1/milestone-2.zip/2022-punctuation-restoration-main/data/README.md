[Link to Google Drive storing data directory](https://drive.google.com/drive/folders/1VYoGqBIPxJM6erhBVz0fdfkFh4jxQHan?usp=sharing)
