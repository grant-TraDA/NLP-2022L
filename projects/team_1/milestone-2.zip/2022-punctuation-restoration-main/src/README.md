**Requirements**:
* [torch](https://pypi.org/project/torch/?msclkid=725777a0cead11ec97f51ea273fc91b0)
* [torchaudio](https://pypi.org/project/torchaudio/?msclkid=6b5c870fcead11ec999d69328ffdaf0f)
* [torchvision](https://pypi.org/project/torchvision/?msclkid=546ec92fcead11ecb0ff8f0daed94b03)
* [transformers](https://pypi.org/project/transformers/?msclkid=80e4d3c5cead11ec9171a758a33f5962) (recommended syntax: `!conda install -c huggingface transformers`)
* [simpletransformers](https://pypi.org/project/simpletransformers/)
